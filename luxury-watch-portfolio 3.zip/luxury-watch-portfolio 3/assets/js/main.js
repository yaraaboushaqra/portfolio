const navToggle = document.querySelector('.nav-toggle');
const siteNav = document.querySelector('.site-nav');
const projectGrid = document.getElementById('projectGrid');
const filters = document.getElementById('filters');
const clientDirectory = document.getElementById('clientDirectory');
const modal = document.getElementById('projectModal');
const modalBody = document.getElementById('modalBody');
const modalClose = document.getElementById('modalClose');

document.getElementById('year').textContent = new Date().getFullYear();

navToggle.addEventListener('click', () => {
  const isOpen = siteNav.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', isOpen);
});

document.querySelectorAll('.site-nav a').forEach(link => {
  link.addEventListener('click', () => siteNav.classList.remove('open'));
});

const categories = ['All', ...new Set(PROJECTS.map(project => project.category))];
filters.innerHTML = categories.map(category => `<button class="filter-button ${category === 'All' ? 'active' : ''}" data-category="${category}">${category}</button>`).join('');

function renderProjects(category = 'All') {
  const visibleProjects = category === 'All' ? PROJECTS : PROJECTS.filter(project => project.category === category);
  projectGrid.innerHTML = visibleProjects.map(project => `
    <article class="project-card" tabindex="0" data-project="${project.id}">
      <img src="${project.cover}" alt="${project.title} cover image" loading="lazy">
      <div class="project-card-content">
        <p class="eyebrow">${project.category} · ${project.year}</p>
        <h3>${project.title}</h3>
        <p>${project.client}</p>
      </div>
    </article>
  `).join('');
}

function renderClients() {
  clientDirectory.innerHTML = CLIENTS.map(client => `
    <article class="client-card">
      <h3>${client.name}</h3>
      <p>${client.type}</p>
      <p>${client.location}</p>
    </article>
  `).join('');
}

filters.addEventListener('click', event => {
  if (!event.target.matches('.filter-button')) return;
  document.querySelectorAll('.filter-button').forEach(button => button.classList.remove('active'));
  event.target.classList.add('active');
  renderProjects(event.target.dataset.category);
});

projectGrid.addEventListener('click', openProjectFromEvent);
projectGrid.addEventListener('keydown', event => {
  if (event.key === 'Enter') openProjectFromEvent(event);
});

function openProjectFromEvent(event) {
  const card = event.target.closest('.project-card');
  if (!card) return;
  const project = PROJECTS.find(item => item.id === card.dataset.project);
  const imagePath = `assets/images/projects/${project.id}/`;
  modalBody.innerHTML = `
    <div class="modal-title">
      <p class="eyebrow">${project.category} · ${project.year} · ${project.client}</p>
      <h2>${project.title}</h2>
      <p>${project.description}</p>
    </div>
    <div class="modal-gallery">
      ${project.images.map(image => `<img src="${imagePath}${image}" alt="${project.title} artwork" loading="lazy">`).join('')}
    </div>
  `;
  modal.showModal();
}

modalClose.addEventListener('click', () => modal.close());
modal.addEventListener('click', event => {
  if (event.target === modal) modal.close();
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach(element => observer.observe(element));
renderClients();
renderProjects();

const nav = document.getElementById('nav');
window.addEventListener('scroll', () => { nav.classList.toggle('scrolled', window.scrollY > 50); }, { passive: true });
